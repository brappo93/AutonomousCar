#include "mbed.h"
#include "rtos.h"
#include "InterruptIn.h"
#include "MODSERIAL.h"
#include "printthread.c"
#include "printbuf.c"

/* FRDM */
DigitalOut led_green(LED_GREEN);
DigitalOut led_red(LED_RED);
DigitalOut led_blue(LED_BLUE);

/* MOTOR DRIVE VARIABLES */
PwmOut motor_en(PTA4);         // ENABLE pin
DigitalOut motor_dir(PTB2);    // DIR pin
DigitalOut motor_br(PTE5);     // BRAKEZ pin
InterruptIn motor_speed(PTD5); // FG1 pin

/* VELOCITY CONTROL */
Timer t;				//interrupt timer
float des_spd;	//desired speed
long numC = 0;	//number of interrupts
double tot_err = 0; //total error
int num = 0;		

/* SERVO VARIABLES */
PwmOut steer(PTA12);           // steering servo PWM
//PwmOut misc(PTD4);

/* STEERING VARIABLES */
unsigned short steer_angles[128]; //map of valid steering angles
unsigned short prev_center = 64;

/* CAMERA VARIABLES */
AnalogIn cam(PTB0);        // Cam AOUT
DigitalOut cam_si(PTC8);   // Cam SI
PwmOut cam_clk(PTA5);      // Cam CLK
InterruptIn clk_in(PTA13);  // for detecting falling edge of CLK
int cam_clk_count, clk_qt; // clock cycle counter and offset
unsigned short cam_data[128];         // for storing raw camera read data
unsigned short cam_frame[16];        // for saving a frame
unsigned short center = 64;           // for storing the line location
unsigned short numFrames = 0;

/* Prototypes */
void print_frame(void);
void cam_isr(void);
unsigned short find_line(unsigned short*);
void camera_setup(void);
void drive_setup(void);
void steer_setup(void);
void speed_isr(void);
float estimate_speed(void);
void set_speed(float);
void set_steer(int);
void flash_led(void);


void print_frame(){
	int i, j;
	for(i=0; i<16; i++){
		cam_frame[i] = 0;
	} //change to memset()
	for(i=0; i<16; i++){
		for(j=i*8; j<(i+1)*8; j++){
			cam_frame[i] += cam_data[j]/8;
		}
		printfNB(" %d",cam_frame[i]/ 6554);
	}
	printfNB(" c: %d\n", center);
}

/* Camera Clock Interrupt Routine */
void cam_isr() {
	if (cam_clk_count == 0) {
		cam_si.write(1); // trigger SI to start
		cam_clk_count++;
	} else if ((cam_clk_count > 0)&&(cam_clk_count < 129+clk_qt)) {
		if (cam_clk_count == 1) {
			cam_si.write(0); // set SI low
	  }
		if (cam_clk_count < 128) {
			cam_data[cam_clk_count-1] = cam.read_u16(); // read in cam pixel
			
		} else if (cam_clk_count == 128) {
			//memcpy(cam_frame, cam_data, sizeof(int)*128);			// copy frame when done
			center = find_line(cam_data); // find line
			if ((center-prev_center)*(center-prev_center) > 500){
				//then it lost the line
				led_red = 0.0;
				center = prev_center;
			}else{
				led_red = 1.0;
			}
			prev_center = center;
			set_steer(center);
			if (0 == numFrames%50){
				//print_frame();
				numFrames = 0;
			}
		  numFrames++;
		}
		cam_clk_count++;
	} else {
		cam_clk_count = 0; // reset
	}
}


/* Line Finding Algorithm */
unsigned short find_line(unsigned short* data) {
	//Operates on the cam_data(cam_frame) integer array
	//Find the center index where the line is on the array 
	//Given we know the length, index 64 would correspond 
	//to the line being right in front of us
	//int l_edge = -1, r_edge = -1, 
	int max_val = -1, max_index = -1;
	for (int i = 0; i<64; i++) {
		if (data[i] >= max_val) {
			max_val = data[i];
			max_index = i;
		}
		if (data[127-i] >= max_val) {
			max_val = data[127-i];
			max_index = 127-i;
		}
		/*if (abs(data[i] - data[i+8]) > 200) {
			return i;
			if (l_edge == -1) l_edge = i;
			else {
				r_edge = i;
				break;
			}
		}*/
	}
	return max_index;//(l_edge+r_edge)/2;
}

/* Camera Clock Setup Routine */
void camera_setup() {
	cam_clk_count = 0;
	clk_qt = 80;
	cam_si.write(0);
	cam_clk.period_us(100);
	cam_clk.write(0.5);
	memset(cam_data, 0, 128*sizeof(unsigned short));
	clk_in.fall(&cam_isr);
}


/* Motor Driver Setup Routine */
void drive_setup() {
	motor_br.write(1);      // Set HIGH to disable braking
	motor_dir.write(1);     // Set HIGH for forward direction
	motor_en.period_us(40); // 25kHz
	set_speed(0.0);    // start off
	//t.start();
	des_spd = 0.0;
	motor_speed.fall(&speed_isr);
}

/* Steering Servo Setup Routine */
void steer_setup() {
	int low = 1196;
	int high = 1704;
	int step_size = 4;
	for (int i=0; i<128; i++){
		steer_angles[i] = low + step_size * i;
	}
	steer.period_ms(20);
	steer.pulsewidth_us(1450); //1200 to 1700 limits left to right; 1450 center0
}

/* Motor Speed Interrupt Routine */
void speed_isr() {
	//t.stop();
	//int total_t = t.read_us();
	numC++;
	//t.reset();
	//est_spd = (0.003583 / total_t) * 1000000;
	//set_speed(des_spd);
	//adjust_speed(des_spd, est_spd);
	//t.start();
}
/* Estimate current velocity */
float estimate_speed(){
	t.stop();
	float time = t.read();
	int n = numC;
	numC = 0;
	t.reset(); 
	t.start();
	if (time == 0.0){
		set_speed(0.00);
		return 0.0;
	}
	
	float speed = n * 0.0001 / time;
	//float speed = n * 0.0358 / t.read(); //not meters lol
	
	float error = des_spd - speed;
	tot_err+= error;
	//error  = error < -1 ? -1 : error > 1 ? 1 : error;
	float p0= 0.05;
	float p = 0.1 * error;
	float i = 0.4 * tot_err;
	float pwm = p + i + p0;
	float inp = pwm < 0.0 ? 0.0 : pwm;
	inp = inp > 0.6 ? 0.6 : inp;
	set_speed(inp);
	if(num%10==0){
		printfNB("Current Speed: %8.5f, Error: %8.5f, Total Error: %8.5f, P Contr: %8.5f, I Contr: %8.5f, PWM: %8.5f\r\n", speed, error, tot_err, p, i, pwm);
	}
	num++;
	
	return speed;
}
/* Set Motor Speed */
void set_speed(float spd) {
	motor_en.write(1.0-spd); // SPD should be between 0.0 - 1.0
}

/* Set Steering Angle */
void set_steer(int pos) {
	//printfNB("%d\r\n",steer_angles[pos]);
	steer.pulsewidth_us(steer_angles[pos]);
}

/* Flash Green LED for diagnostics */
void flash_led() {
	led_green.write(0); // Note that the internal LED is active LOW
	wait(0.25);
	led_green.write(1);
	wait(0.25);
}

/* Main! */
int main() {
	led_blue = 1.0;
	led_red = 1.0;
	flash_led();
	
	wait(5);
	flash_led();
	flash_led();
	
	serial.baud(9600);
	Thread printThread(print_thread);
	printfNB("\r\nBuilt " __DATE__ " " __TIME__ "\r\n");
	
	/* Setup routines */
	//print_setup();
	drive_setup();
	camera_setup();
	steer_setup();


	des_spd = 0.035;
	for(int i =0; ; i++){
		estimate_speed();
		wait(0.10);
	}
	des_spd = 0.0;
	set_speed(0.0);
	

	
	Thread::wait(osWaitForever);

}