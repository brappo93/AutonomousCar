#include "mbed.h"
#include "rtos.h"
#include "rt_Time.h"
#include "MODSERIAL.h"
#include "stdint.h"
// using rtos builtin timer
uint32_t systime = 0; // systime updated every 100 us for timing purposes
uint32_t systime1 = 0; // systime updated every 100 us for timing purposes

MODSERIAL serial(USBTX, USBRX);

extern "C" { extern int printfNB(const char *format, ...); }
extern "C" {extern int putcharNB(int);}



// print thread - non blocking method for handling printing
#define PRNBUFSZ 0x100
extern char printbuffer[PRNBUFSZ];
extern int prnbuf_count;   /* number of characters in buffer */
extern int prnbuf_pos;   /* location to store characters */

void print_thread(void const *args)
{ char c; int index;
	while(1)
	{	Thread::wait(1000); // should be 0.1 sec}
	// process print buffer in thread, so won't block
		while (prnbuf_count > 0)  /* there are characters to print */
		{  index = prnbuf_pos - prnbuf_count;
       if(index < 0) index = index +PRNBUFSZ;  /* wrap around */
       c = printbuffer[index];
		   serial.putc(c); // print one character, blocking or not
       prnbuf_count--;
		}
	}
}
	
	/*
void print_thread_status(long value)
{		switch(value)
		{ case 0: serial.printf("Inactive "); break;
		  case 1: serial.printf("Ready "); break;
			case 2: serial.printf("Running "); break;
			case 3: serial.printf("WaitingDelay "); break;
			case 4: serial.printf("WaitingInterval "); break;
			default: serial.putc('?');
		}
}
*/
